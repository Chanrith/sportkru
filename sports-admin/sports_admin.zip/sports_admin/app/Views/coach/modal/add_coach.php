<!-- <div class="row"> -->
<form action="" id="addCoach">
<div class="row">
    <div class="form-group col-6">
         <label class="mt-3" for="name">Name *</label>
         <input type="text" class="form-control" id="name" placeholder="Name" name="name" >
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="mobile_number">Mobile Number *</label>
         <input type="number" class="form-control" id="mobile_number" placeholder="Mobile Number" name="mobile_number"  maxlenght="10" minlength="10" >
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="alternative_number">Alternative Number *</label>
         <input type="number" class="form-control" id="alternative_number" placeholder="Alternative Number" name="alternative_number"  maxlenght="10" minlength="10" >
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="email">Email </label>
         <input type="email" class="form-control" id="email" placeholder="Email" name="email" >
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="class_schedule">Classs schedule</label>
         <input type="text" class="form-control" id="class_schedule" placeholder="Classs Schedule" name="class_schedule" >
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="sports_type">Sports Type *</label>
         <select class="form-control select2" id="sports_type" name="sports_type" >
            <?php foreach($sports_type as $row){?>
            <option value="<?=$row->type_name?>"><?=$row->type_name?></optoin>
            <?php }?>
        </select>
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="couch_timing">Couch Timing *</label>
         <select class="form-control select2" id="couch_timing" name="couch_timing" >
            <?php foreach($sports_timings as $row){?>
            <option value="<?=$row->type_name?>"><?=$row->type_name?></optoin>
            <?php }?>
        </select>
     </div>
     <div class="form-group col-6">
         <label class="mt-3" for="image">Image </label>
         <!-- <input type="file" class="form-control" accept=".png,.jpeg,.jpg" id="image" name="image" > -->
         <label class="row  justify-content-center mx-0 floating-label" style="height: 60px;border: 1px solid #ced4da;border-radius:4px;background:#fff;top: 23px;left: 4px;" for="image">
            <input type="file" name="image" class="d-none" id="image" accept=".png, .jpg, .jpeg" oninput="document.getElementById('imageImage').src=window.URL.createObjectURL(this.files[0]);" required="required">
            <img id="imageImage" onerror="this.src='<?=base_url()?>/assets/images/default-img.png';"  style="max-width:100%;max-height:100%;">
        </label>
     </div>
</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button id="submit" class="btn btn-success">Save</button>
    </div>
</form>
<!-- </div> -->
<script type="text/javascript">
	$(document).ready(function() {
        $(".select2").select2();
		 $('#addCoach').formValidation({
	           framework: 'bootstrap',
	           fields: {
                name: {
	                   validators: {
	                       notEmpty: {message: 'Name is required'},
	                   }
	               	},
                mobile_number: {
	                   validators: {
	                       notEmpty: {message: 'Mobile Number is required'},
	                   }
	               	},
                alternative_number: {
                        validators: {
                            notEmpty: {message: 'Alternative Number is required'},
                        }
                    },
                email: {
                        validators: {
                            notEmpty: {message: 'Email is required'},
                        }
                    },
                class_schedule: {
	                   validators: {
	                       notEmpty: {message: 'Class Schedule is required'},
	                   }
	               	},
                couch_timing: {
                        validators: {
                            notEmpty: {message: 'Couch Timing is required'},
                        }
                    },
	           }
	       })
	       .on('success.form.fv', function(e) { 
	           e.preventDefault(); 
	           var form = document.querySelector('#addCoach');
	           var formData = new FormData(form);
	           $.ajax({
	               type:'POST',
	               url: '<?=base_url()?>/sportscoach/saveCoach', 
	               data:formData,
	               cache:false,
	               contentType: false,
	               processData: false, // serializes the form's elements.
	               dataType:'json',
	               success:function(result)
	               {
                    if(result==false)
                    {
                        toastr.warning('Mobile number already exist','Already Exist');
                    }
                    else if(result==true)
                    {
                        $('#modal_lg').modal('hide');
                        toastr.success('Coach added successfully','Success');
                        getSportsCoach()
                    }
	               }
	           });
	       });
	   });
</script>