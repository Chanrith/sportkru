<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?=base_url()?>/assets\css\AdminLTE.min.css">
<style type="text/css">
	.highcharts-credits{display: none;}
	.content::-webkit-scrollbar {
	display: none;
	}
</style>
<!--Dashboard-->
<section class="content-header">
	<h1>Dashboard</h1>
</section>
<div style="height:146px;">
	<section class="content d-flex " style="overflow-x:scroll;">
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-aqua">
				<div class="inner">
					<h3></h3>
					<p>Total Online Booking</p>
				</div>
				<div class="icon"><i class="ion ion-bag"></i></div>
				<a href="<?=base_url()?>booking-report" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-yellow">
				<div class="inner">
					<h3></h3>
					<p>Total Customer</p>
				</div>
				<div class="icon"><i class="fa fa-user"></i></div>
				<a href="<?=base_url()?>customers" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-green">
				<div class="inner">
					<h3></h3>
					<p>Total Easy Pay</p>
				</div>
				<div class="icon"><i class="fa fa-inr"></i></div>
				<a href="<?=base_url()?>easypay" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-red">
				<div class="inner">
					<h3></h3>
					<p>Total Enquiry</p>
				</div>
				<div class="icon"><i class="fa fa-newspaper"></i></div>
				<a href="<?=base_url()?>enquiry-report" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-yellow">
				<div class="inner">
					<h3></h3>
					<p>Total Want To Us Call</p>
				</div>
				<div class="icon"><i class="fa fa-phone"></i></div>
				<a href="<?=base_url()?>want-to-us-call-report" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-green">
				<div class="inner">
					<h3></h3>
					<p>Total News Letter</p>
				</div>
				<div class="icon"><i class="fa fa-newspaper"></i></div>
				<a href="<?=base_url()?>news-letter-report" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-sm-6">
			<div class="small-box bg-aqua">
				<div class="inner">
					<h3></h3>
					<p>Total Tours</p>
				</div>
				<div class="icon"><i class="fa fa-users"></i></div>
				<a href="<?=base_url()?>tour" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
	</section>
</div>
<!--Dashboard end-->
<!-- Page Content-->
<div class="page-content">
<div class="container-fluid">
	<!--end row--><!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-lg-8 mt-2">
			<div class="card">
				<div class="card-header">
					<div class="row align-items-center">
						<div class="col">
							<h4 class="card-title">Revenue Status</h4>
						</div>
					</div>
					<!--end row-->
				</div>
				<!--end card-header-->
				<div class="card-body">
					<div class="">
						<div class="v-pv-weekly" id="barChart" style="height: 350px; width: 100%; margin-top: 30px;"></div>
					</div>
				</div>
				<!--end card-body-->
			</div>
			<!--end card-->
		</div>
		<!-- end col--> 
		<div class="col-lg-4 mt-2">
			<div class="card">
				<div class="card-header">
					<div class="row align-items-center">
						<div class="col">
							<h4 class="card-title">Earning Reports</h4>
						</div>
						<!--end col-->
					</div>
					<!--end row-->
				</div>
				<!--end card-header-->
				<div class="card-body border-bottom-dashed">
					<div class="earning-data text-center">
						<img src="assets/images/money-beg.png" alt="" class="money-bag my-3" height="60">
						<h5 class="earn-money mb-1">₹ </h5>
						<p class="text-muted font-15 mb-4">This Month Revenue</p>
						<div class="text-center my-2">
							<h6 class="text-primary bg-soft-primary p-4 mb-0 font-11 rounded"></span> <i data-feather="dollar-sign" class="align-self-center icon-xs mr-1"></i> Last Month ₹ </h6>
						</div>
					</div>
				</div>
				<!--end card-body-->
				<div class="card-body my-1">
					<div class="row">
						<div class="col">
							<div class="media">
								<i data-feather="shopping-cart" class="align-self-center icon-md text-secondary mr-2"></i>
								<div class="media-body align-self-center">
									<h6 class="m-0 font-24"></h6>
									<p class="text-muted mb-0">Today's booking</p>
								</div>
								<!--end media body-->
							</div>
						</div>
						<!--end col-->
						<div class="col">
							<div class="media">
								<i data-feather="dollar-sign" class="align-self-center icon-md text-secondary mr-2"></i>
								<div class="media-body align-self-center">
									<h6 class="m-0 font-24">₹</h6>
									<p class="text-muted mb-0">Today's Revenue</p>
								</div>
								<!--end media body-->
							</div>
						</div>
						<!--end col-->
					</div>
					<!--end row-->
				</div>
				<!--end card-body-->
			</div>
			<!--end card-->
		</div>
		<!-- end col-->
	</div>
	<!--end row-->
	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<div class="card-header">
					<div class="row align-items-center">
						<div class="col">
							<h4 class="card-title">Recent customer</h4>
						</div>
						<!--end col-->
					</div>
					<!--end row-->
				</div>
				<!--end card-header-->
				<div class="card-body">
					<div class="table-responsive">
						<table class="table mb-0">
							<thead class="thead-light">
								<tr>
									<th class="border-top-0">Date</th>
									<th class="border-top-0">Customer Name</th>
									<th class="border-top-0">Mobile Number</th>
									<th class="border-top-0">Status</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
						<!--end table-->
					</div>
					<!--end /div-->
				</div>
				<!--end card-body-->
			</div>
			<!--end card-->
		</div>
		<!--end col-->
		<div class="col-lg-6">
			<div class="card">
				<div class="card-header">
					<div class="row align-items-center">
						<div class="col">
							<h4 class="card-title">Recent bookings</h4>
						</div>
						<!--end col-->
					</div>
					<!--end row-->
				</div>
				<!--end card-header-->
				<div class="card-body">
					<div class="table-responsive">
						<table class="table mb-0">
							<thead class="thead-light">
								<tr>
									<th class="border-top-0">Date</th>
									<th class="border-top-0">Customer Name</th>
									<th class="border-top-0">Tour</th>
									<th class="border-top-0">Amount</th>
								</tr>
								<!--Sample tr end-->
							</thead>
							<tbody>
							</tbody>
						</table>
						<!--end table-->
					</div>
					<!--end /div-->
				</div>
				<!--end card-body-->
			</div>
			<!--end card-->
		</div>
		<!--end col-->
	</div>
	<!--end row-->
</div>
<!-- container -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>
<script type="text/javascript">
	Highcharts.setOptions({
	
	    lang: {
	
	        decimalPoint: '.',
	
	        thousandsSep: ','
	
	    }
	
	});
	
	$('#barChart').highcharts({
	
	    chart: {
	
	        type: 'column'
	
	    },
	
	    title: {
	
	        text: 'Booking Report'
	
	    },
	
	    subtitle: {
	
	        text: ''
	
	    },
	
	    xAxis: {
	
	        categories: [
	
	            <?php $j=6;for($i=1;$i<=6;$i++){$month=$j-$i;echo "'".date('M-Y',strtotime("-$month months"))."',"; } ?>
	
	        ],
	
	        crosshair: true
	
	    },
	
	    yAxis: {
	
	        min: 0,
	
	        title: {
	
	            text: 'Report For Last 6 Months'
	
	        }
	
	    },
	
	    tooltip: {
	
	        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
	
	        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
	
	            '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
	
	        footerFormat: '</table>',
	
	        shared: true,
	
	        useHTML: true
	
	    },
	
	    
	
	    series: [{
	
	        name: 'Bookings',
	
	        data: [
	
	        100,200,240,123,324
	
	        ]
	
	
	
	    }]
	
	});   
	
</script>