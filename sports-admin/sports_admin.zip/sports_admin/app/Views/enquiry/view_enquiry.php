<div class="">
   <div class="row ">
   </div>
   <div class="row">
      <div class="col-12 table-responsive">
         <h4>Details</h4>
         <table class="table table-bordered ">
               <tr>
                   <th>Name</th>
                   <td><?=$enquiry->name?></td>
               </tr>
               <tr>
                   <th>Contact Person</th>
                   <td><?=$enquiry->contact_person?></td>
               </tr>
               <tr>
                   <th>Email</th>
                   <td><?=$enquiry->email?></td>
               </tr> 
               <tr>
                   <th>Number</th>
                   <td><?=$enquiry->number?></td>
               </tr>
               <tr>
                   <th>Message</th>
                   <td><?=$enquiry->message?></td>
               </tr>
               <tr>
                   <th>Plan</th>
                   <td><?=$enquiry->plan?></td>
               </tr>        
               <tr>
                   <th>Type</th>
                   <td><?=$enquiry->type?></td>
               </tr>                                  
         </table>
		</div>
      <div class="col-md-12 modal-footer text-right"style="padding-left:0px;" >
         <button class="btn btn-sm btn-secondary" type="button" data-dismiss="modal">Cancel</button>
	  </div>
<div>
